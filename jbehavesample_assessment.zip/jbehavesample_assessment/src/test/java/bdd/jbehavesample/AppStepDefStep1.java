package bdd.jbehavesample;

import org.jbehave.core.annotations.When;

import net.thucydides.core.annotations.Shared;
import net.thucydides.core.annotations.Step;

public class AppStepDefStep1 {

	@Shared
	AppStepDefinitions shared;
	int sum;
	int difference;
	int quotient;
	int reminder;
	int product;
	@Step
	@When(value = "I add these numbers")
	public void method2(){
		sum = shared.a+shared.b;
	}
	
	@When(value = "I subtract one number from other")
	public void method2Subtraction(){
		difference = shared.a-shared.b;
	}
	
	@When(value = "I divide one number with other")
	public void method2Quotient(){
		quotient = shared.a/shared.b;
	}
	
	@When(value = "I divide one number with other to get reminder")
	public void method2Reminder(){
		reminder = shared.a%shared.b;
	}
	
	@When(value = "I multiply one number with other")
	public void method2Product(){
		product = shared.a*shared.b;
	}
}

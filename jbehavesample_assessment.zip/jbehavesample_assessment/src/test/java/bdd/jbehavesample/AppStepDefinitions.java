package bdd.jbehavesample;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;

import net.thucydides.core.annotations.Steps;

/**
 * Unit test for simple App.
 */
public class AppStepDefinitions 
{
	@Steps(shared=true)
	AppStepDefStep1 appStepDefStep1;
	int a; int b;
	@Given(value = "I have two numbers <value1> and <value2>")
	public void method1(@Named("value1") int value1,@Named("value2") int value2){
		a = value1;
		b = value2;
	}
	
	@Then(value = "The total should be <sum>")
	public void method3(@Named("sum") int sumFromStory){
		if(appStepDefStep1.sum==sumFromStory) {
			System.out.println("Passed");
		}else {
			System.out.println("Failed");
		}
	}
	
	
	@Given(value = "I have two numbers <value3> and <value4>")
	public void method1Subtraction(@Named("value3") int value3,@Named("value4") int value4){
		a = value3;
		b = value4;
	}
	
	@Then(value = "The difference should be <difference>")
	public void method3Subtraction(@Named("difference") int diffFromStory){
		if(appStepDefStep1.difference==diffFromStory) {
			System.out.println("Passed");
		}else {
			System.out.println("Failed");
		}
	}

	
	@Given(value = "I have two numbers <value5> and <value6>")
	public void method1Quotient(@Named("value5") int value5,@Named("value6") int value6){
		a = value5;
		b = value6;
	}
	
	@Then(value = "The quotient should be <quotient>")
	public void method3Quotient(@Named("quotient") int quoFromStory){
		if(appStepDefStep1.quotient==quoFromStory) {
			System.out.println("Passed");
		}else {
			System.out.println("Failed");
		}
	}
	
	@Given(value = "I have two numbers <value7> and <value8>")
	public void method1Reminder(@Named("value7") int value7,@Named("value8") int value8){
		a = value7;
		b = value8;
	}
	
	@Then(value = "The reminder should be <reminder>")
	public void method3Reminder(@Named("reminder") int remFromStory){
		if(appStepDefStep1.reminder==remFromStory) {
			System.out.println("Passed");
		}else {
			System.out.println("Failed");
		}
	}
	
	@Given(value = "I have two numbers <value9> and <value10>")
	public void method1Product(@Named("value9") int value9,@Named("value10") int value10){
		a = value9;
		b = value10;
	}
	
	@Then(value = "The product should be <product>")
	public void method3Product(@Named("product") int remFromProduct){
		if(appStepDefStep1.product==remFromProduct) {
			System.out.println("Passed");
		}else {
			System.out.println("Failed");
		}
	}
}
